﻿namespace ProjectUnderTest
{
    public class Arithmetic
    {
        public static long GenerateFactorial(int number)
        {   long result = 1;
            for(int i = 1; i <= number; i++)
            {
                result = result * i;
            }
            return result;
        }
    }
}
