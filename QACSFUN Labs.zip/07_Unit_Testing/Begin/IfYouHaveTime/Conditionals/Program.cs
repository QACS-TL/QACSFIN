﻿using Conditionals;

namespace Conditionals
{
    public class Program
    {
        public static void Main()
        {
            Console.WriteLine("##### If Statement #####");
            Pole pole = Pole.North;
            string animal;

            animal = GetArcticAnimal(pole);
            Console.WriteLine($"The animal that lives in the {pole} Pole is the {animal}");

            Console.WriteLine("##### Ternary Statement #####");
            pole = Pole.South;

            string animal2 = (pole == Pole.North ? "Polar Bear" : "Penguin");
            Console.WriteLine($"The animal that lives in the {pole} Pole is the {animal2}");


            Console.WriteLine("##### Switch Statement #####");
            CapitalCities city = CapitalCities.Madrid;
            string countryMessage = GetCountryForCapitalCity(city);
            Console.WriteLine(countryMessage);

        }

        public static string GetCountryForCapitalCity(CapitalCities city)
        {
            string countryMessage = "";

            switch (city)
            {
                case CapitalCities.Paris:
                    countryMessage = $"{city} is the capital of France";
                    break;
                case CapitalCities.Madrid:
                    countryMessage = $"{city} is the capital of Spain";
                    break;
                case CapitalCities.London:
                    countryMessage = $"{city} is the capital of England";
                    break;
                case CapitalCities.Rome:
                    countryMessage = $"{city} is the capital of Italy";
                    break;
                default:
                    countryMessage = $"{city} is not a known capital city";
                    break;
            }

            return countryMessage;
        }

        public static string GetArcticAnimal(Pole pole)
        {
            string animal;
            if (pole == Pole.North)
            {
                animal = "Polar Bear";
            }
            else
            {
                animal = "Penguin";
            }

            return animal;
        }
    }
}